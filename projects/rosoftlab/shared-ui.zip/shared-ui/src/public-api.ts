/*
 * Public API Surface of shared-ui
 */

export * from './lib/generic-crud.component';
export * from './lib/generic-table.component';

